#include <iostream>

int main()
{
	int a;
	std::cin >> a;	
	a = a | 15;
	std::cout << a << std::endl;
	return 0;
}
